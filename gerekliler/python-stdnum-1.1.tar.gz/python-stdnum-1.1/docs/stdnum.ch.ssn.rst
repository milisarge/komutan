stdnum.ch.ssn
=============

.. automodule:: stdnum.ch.ssn
   :members:
