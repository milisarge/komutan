stdnum.is_.kennitala
====================

.. automodule:: stdnum.is_.kennitala
   :members: