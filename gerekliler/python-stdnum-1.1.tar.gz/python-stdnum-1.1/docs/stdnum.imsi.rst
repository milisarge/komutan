stdnum.imsi
===========

.. automodule:: stdnum.imsi
   :members:
